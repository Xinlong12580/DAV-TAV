#ifndef __PDB_HH__
#define __PDB_HH__

typedef int PdbStatus;

#ifdef NULL
#undef NULL
#endif
#define NULL 0

#endif /* __PDB_HH__ */

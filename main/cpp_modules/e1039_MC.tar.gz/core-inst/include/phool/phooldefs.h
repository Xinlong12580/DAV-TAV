#ifndef PHOOLDEFS_H__
#define PHOOLDEFS_H__

#include <string>

namespace phooldefs
{
  static const std::string branchpathdelim = ".";
  static const std::string nodetreepathdelim = "/";
};

#endif


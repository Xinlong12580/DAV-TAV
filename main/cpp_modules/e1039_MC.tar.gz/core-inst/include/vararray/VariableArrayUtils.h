#ifndef VARIABLEARRAYUTILS_H__
#define VARIABLEARRAYUTILS_H__

class VariableArrayUtils
{
 public:
  static short FloatToShortBits(const float rval);
  static float ShortBitsToFloat(const short ival);
};

#endif

